-------------------------------------
Snap7 IoT Package for ARM architecure
-------------------------------------

Card Tested
-------------------------
Raspberry Pi 1     ARM V6
Raspberry Pi 2     ARM V7
Raspberry Pi 3     ARM V7 
Raspberry Pi 4     ARM V7 
Raspberry Pi 4     ARM V7 x64 (02-11-2020)
Beaglebone Black   ARM V7
CubieBoard         ARM V7 
PcDuino            ARM V7
Udoo Quad          ARM V7 
Mele A2000         ARM V7



